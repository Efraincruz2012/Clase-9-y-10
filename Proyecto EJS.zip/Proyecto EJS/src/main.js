const express = require('express')

const producto = []

const app = express()

app.use(express.urlencoded({ extended: true }))
//motor de vistas
app.set('views', './views');
app.set('view engine', 'ejs');
//endpoint para cargar la pagina de inicio
app.get('/', (req, res) => {
    res.render('inicio', { producto }); // carga la pagina de inicio "va a buscar Incio.ejs"
});
app.get('/Historial', (req, res) => {
    res.render('inicio1', { producto }); // carga la pagina de inicio "va a buscar Incio.ejs"
    res.redirect('/Historial')
});


// endpoint para recivir el post de personas
app.post('/producto', (req, res) => {
    producto.push(req.body)
    console.log(producto)
    res.redirect('/')
    

});







// servidor
const PORT = 8080
const server = app.listen(PORT, () => {
    console.log(`Servidor escuchando en el puerto ${server.address().port}`)
})
server.on('error', error => console.log(`Error en servidor ${error}`))